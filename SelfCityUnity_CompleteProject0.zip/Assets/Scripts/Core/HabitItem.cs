// Example: Assets/Scripts/Core/HabitItem.cs
namespace LifeCraft.Core
{
    public class HabitItem
    {
        // Add properties and methods as needed
    }
}