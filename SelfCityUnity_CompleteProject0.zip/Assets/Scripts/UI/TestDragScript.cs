using UnityEngine;
public class TestDragScript : MonoBehaviour
{
    public TestToDoListManager testToDoListManager; // Reference to the TestToDoListManager script to call AddToDo method. 
}