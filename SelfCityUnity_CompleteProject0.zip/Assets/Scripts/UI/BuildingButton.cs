using UnityEngine;

namespace LifeCraft.UI
{
    public class BuildingButton : MonoBehaviour
    {
        // Stub for migration compatibility
        public void Initialize() { }

        public void Initialize(LifeCraft.Systems.UnlockSystem.UnlockableBuilding building, System.Action<string> onClick) { }
    }
} 